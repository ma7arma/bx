# Bixah QR Shock Demo — One Page (No Popup)
- Mobile-first, single page.
- No consent popup; buttons are inline.
- Shows: Platform, Languages, Device memory, Connection status, Theme, Touch/Mouse activity (live), Camera preview (on consent), Location (on consent).
- No storage, no network calls.
- Footer: "Check our booth."

## Publish (ma7arma/bx)
1) Upload `index.html` and `assets/favicon.svg` to the repo root.
2) Settings → Pages → Deploy from branch → `main` → `/root`.
3) Open: https://ma7arma.github.io/bx/?mode=shock
